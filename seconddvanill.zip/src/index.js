document.getElementById("app").innerHTML = `
<h1>Hello You!</h1>
<div>
  Iam not crazy I promise, if you don't believe me look
  <a href="http://mope.io/" target="_blank" rel="noopener noreferrer">here</a>
  !
</div>
`;
